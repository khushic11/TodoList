import React from 'react';
import './App.css';
import Todolist from './todolist';

const App =()=>{
  return (
    <div>
      <Todolist/>
    </div>
  );
};

export default App;


